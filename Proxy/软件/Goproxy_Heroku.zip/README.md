goproxy 正式版下载 [http://git.io/goproxy](https://github.com/phuslu/goproxy/releases)

## 讨论区
* https://github.com/phuslu/goproxy/issues

## 文档
* 简易教程 https://github.com/phuslu/goproxy/blob/wiki/SimpleGuide.md
* 图文教程 https://github.com/phuslu/goproxy/blob/wiki/InstallGuide.md
* 常见问题 https://github.com/phuslu/goproxy/blob/wiki/FAQ.md
* 配置介绍 https://github.com/phuslu/goproxy/blob/wiki/ConfigIntroduce.md
* 更新历史 https://github.com/phuslu/goproxy/blob/wiki/History.md

## 代码
 * goproxy https://github.com/phuslu/goproxy
 * goagent.exe https://github.com/phuslu/taskbar
